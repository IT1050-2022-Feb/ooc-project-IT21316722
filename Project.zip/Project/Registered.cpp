#include "Registered.h"
#include "Person.h"

Registered::Registered(){
  cout << "Default Registered Constructor called " << endl; 
}
Registered::Registered(int rid, string rmail, string raddress, string rwallet){

  // attributes related to parent
  name = "NIMAL";
  password = "@#nim!qRyeyu799";
  email = "nim@gmail.com";
  // attributes related to child 
  id=rid;
  email_ID=rmail;
  address=raddress;
  wallet=rwallet;
  
  cout << "Registered Overloaded Constructor Called"<<endl;
    cout << "REGISTERED ID : " << id << endl
         << "NAME : " << name << endl
         << "EMAIL : " << email << endl
         << "PASSWORD : " << password << endl
         << "EMAIL ID : " << email_ID << endl
         << "ADDRESS : " << address << endl
         << "WALLET : " << wallet << endl
         << endl;
}

void Registered::setDetails(string rmail, string raddress, string rwallet){}
void Registered::setId(int rid){}
int Registered::getId(){}
string Registered::getDetails(){}
void Registered::displayDetails(){}
Registered::~Registered(){
  
  cout << "Registered  destructor called " << endl; 
  
}