#include "Person.h"
#include "Registered.h"

#include <iostream>
using namespace std;

int main() {

  Person pp1(875603767, "Surinimal", "@#!qRyeyu728", "qwe@gmail.com");

  Registered r1(1100, "EM200", "KURUNEGALA", "DEBIT_VISA");

  return 0;
}
