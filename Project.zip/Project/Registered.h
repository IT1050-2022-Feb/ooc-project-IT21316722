#include "Person.h"
#include<iostream>
using namespace std;

class Registered : public Person{
private:
  int id;
  string email_ID;
  string address;
  string wallet;
public:
  Registered();
  Registered(int rid,string rmail,string raddress,string rwallet);
  void setDetails(string rmail,string raddress,string rwallet);
  void setId(int rid);
  int getId();
  string getDetails();
  void displayDetails();
  ~Registered();
};